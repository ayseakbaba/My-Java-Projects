public class Oop_Atm_Hesap {
    private String kullaniciadi;
    private String parola;
    private double bakiye;


    public Oop_Atm_Hesap(String kullaniciadi , String parola , double bakiye){
        this.kullaniciadi=kullaniciadi;
        this.parola =parola;
        this.bakiye = bakiye;
    }


    public  void setkullaniciadi(String kullaniciadi){
        this.kullaniciadi = kullaniciadi;
    }
    public String getkullaniciadi(){
        return kullaniciadi;
    }


    public void setparola(String parola){
        this.parola = parola;
    }
    public  String getparola(){
        return parola;
    }


    public void setbakiye(double bakiye){
        this.bakiye= bakiye;
    }
    public double getbakiye(){
        return bakiye;
    }


    public void parayatir(int miktar){
        bakiye+=miktar;
        System.out.println("Yeni Bakiye : " + bakiye);
    }


    public void paracekme(int miktar){
        if(miktar > 1500){
            System.out.println("Günlük Para Çekme Limitiniz : 1500 TL' dir.");
        }
        if(miktar > bakiye){
            System.out.println("Yetersiz Bakiye! Mevcut Bakiyeniz : " + bakiye);
        }else{
            bakiye-= miktar;
            System.out.println("Para Çekme İşlemi Başarılı.");
            System.out.println("Kalan Bakiye : " + bakiye);
        }
    }
}
