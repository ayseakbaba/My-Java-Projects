import java.util.Scanner;

public class Oop_Atm {
    public void calıs(Oop_Atm_Hesap hesap){
        Oop_Atm_Giris giris = new Oop_Atm_Giris();

        Scanner in = new Scanner(System.in);
        System.out.println("Bankamıza Hoşgeldiniz...");
        System.out.println("**********************************");
        System.out.println("Kullanıcı Girişi: ");
        System.out.println("**********************************");

        int girishakki = 3;
        while(true){
            if(giris.giris(hesap)){
                System.out.println("Giriş Başarılı...");
                break;
            }else{
                System.out.println("Giriş Başarısız...");
                girishakki -=1;
                System.out.println("Kalan Giriş Hakkı: " + girishakki);
            }
            if(girishakki ==0){
                System.out.println("Giriş Hakkınız Bitmiştir...");
                return;
            }
        }
        System.out.println("**********************************");
        String islemler = "1. Bakiye Görüntüle\n"
                        + "2. Para Yatırma\n"
                        + "3. Para Çekme \n"
                        + "4. Çıkış için 'q'ya basın";
        System.out.println(islemler);
        System.out.println("**********************************");

        while(true){
            System.out.print("İşlemi Seçin: ");
            String islem = in.nextLine();

            if(islem.equals("q")){
                break;
            }else if(islem.equals("1")){
                System.out.println("Bakiyeniz: "+ hesap.getbakiye());
            }else if(islem.equals("2")){
               System.out.print("Yatırmak İstediğiniz Miktar: ");
               int miktar=in.nextInt();
               in.nextLine(); 
               hesap.parayatir(miktar);
            }else if(islem.equals("3")){
                System.out.print("Çekmek İstediğiniz Miktar: ");
                int miktar = in.nextInt();
                in.nextLine();
                hesap.paracekme(miktar);
            }else{
                System.out.println("Geçersiz İşlem...");
            }
        }
        in.close();
    }
}
       
