public class Oop_Atm_Main {
    public static void main(String[] args) {
        Oop_Atm atm = new Oop_Atm();
        Oop_Atm_Hesap hesap = new Oop_Atm_Hesap("Ayse", "12345", 2000);

        atm.calıs(hesap);
        System.out.println("Programdan Çıkılıyor.Yine Bekleriz...");
    }
}
