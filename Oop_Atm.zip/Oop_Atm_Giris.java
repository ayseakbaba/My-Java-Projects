import java.util.Scanner;

public class Oop_Atm_Giris {
    public boolean giris(Oop_Atm_Hesap hesap){
        Scanner in = new Scanner(System.in);
        String kullaniciadi , parola;
        System.out.print("Kullanıcı Adı: ");
        kullaniciadi= in.nextLine();
        System.out.print("Parola: ");
        parola= in.nextLine();
        
        if(hesap.getkullaniciadi().equals(kullaniciadi) && hesap.getparola().equals(parola)){
            return true;
        }else{
            return false;
        }
    }



}
