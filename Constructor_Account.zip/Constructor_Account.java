public class Constructor_Account {
    private String hesapNo;
    private double bakiye;
    private String isim;
    private String email;
    private String telNo;

    public Constructor_Account (String hesapNo , double bakiye , String isim , String email , String telNo){
        this.bakiye = bakiye;
        this.email = email;
        this.hesapNo = hesapNo;
        this.isim = isim;
        this.telNo = telNo;
    }

    public void parayatirma(double miktar){
        bakiye += miktar;
        System.out.println("Yeni bakiye = " + bakiye);
    }

    public void paraçekme( double miktar){
        if (bakiye>1500){
            System.out.println("Tek seferden 1500'den fazla para çekilemez ...");
        }
        if(miktar> bakiye){
            System.out.println("Yetersiz bakiye... Mevccut bakiyeniz = " + bakiye);
        }else{
            bakiye -= miktar;
            System.out.println("Kalan bakiye = " + bakiye);
        }
    }
    public Constructor_Account(String isim , String telNo , String email){
        this("Bilgi Yok", 0.0, isim, email, telNo);
    }

    public Constructor_Account (){
        //System.out.println("Kendi yazdığım construction ...");
        this("Bilgi Yok", 0.0,"Bilgi Yok","Bilgi Yok","Bilgi Yok");
    }

    public void bilgilerigoster(){
        System.out.println("İsim:" +this.isim);
        System.out.println("Hesap No: " + this.hesapNo);
        System.out.println("Bakiye: " + this.bakiye);
        System.out.println("E-mail: " + this.email);
        System.out.println("Telefon Numarası: "+ this.telNo);
    }

    public void bakiye(double bakiye){
        this.bakiye =bakiye;
    }
    public double getbakiye(){
        return bakiye;
    }


    public void hesapNo(String hesapNo){
        this.hesapNo = hesapNo;
    }
    public String gethesapNo(){
        return hesapNo;
    }


    public void isim(String isim){
        this.isim = isim;
    }
    public String getisim(){
        return isim;
    }


    public void email(String email){
        this.email = email;
    }
    public String getemail(){
        return email;
    }


    public void telNo(String telNo){
        this.telNo = telNo;
    }
    public String gettelNo(){
        return telNo;
    }
}
