public class Constructor_Account_Test {
    public static void main(String[] args) {
        Constructor_Account account1 = new Constructor_Account();
        System.out.println(account1.getemail());

        Constructor_Account account2 = new Constructor_Account("Ayşe AKBABA" , "example@gmail.com" , "23579876543456");
        /*System.out.println(account2.gethesapNo());
        System.out.println(account2.getemail());*/
        account2.bilgilerigoster();

        
    }
}
