public class Inheritance_Hayvan {
    private String isim;
    private int kilo;
    private int boy;
    private int bacakSayisi;

    public  Inheritance_Hayvan(String isim , int kilo , int boy , int bacakSayisi){
        this.isim = isim;
        this.kilo = kilo;
        this.boy= boy;
        this.bacakSayisi = bacakSayisi;
    }


    public void setIsim(String isim){
        this.isim=isim;
    }
    public String getIsim(){
        return isim;
    }


    public void setKilo(int kilo){
        this.kilo = kilo;
    }
    public int getKilo(){
        return kilo;
    }


    public void setBoy(int boy){
        this.boy = boy;
    }
    public int getBoy(){
        return boy;
    }


    public void setbacakSayisi(int bacakSayisi){
        this.bacakSayisi = bacakSayisi;
    }
    public int getbacakSayisi(){
        return bacakSayisi;
    }


    public void yemeyYe(){
        System.out.println("Hayvan Şu Anda Yemek Yiyor...");
    }

    public void hareketHizi(int hiz){
        System.out.printf("Hayvanın hareket hızı: %d m/s" , hiz);
    }
}
