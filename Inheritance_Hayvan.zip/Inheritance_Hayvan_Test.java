public class Inheritance_Hayvan_Test {
    public static void main(String[] args) {
        
        Inheritance_Kopek kopek = new Inheritance_Kopek("Karabaş", 12, 50, 4, 42);
        kopek.kos(12);
    }
}
