public class Inheritance_Kopek extends Inheritance_Hayvan {
    private int disSayisi;

    public Inheritance_Kopek(String isim , int kilo ,int boy , int bacakSayisi , int disSayisi){
        super(isim, kilo, boy, bacakSayisi);
        this.disSayisi = disSayisi;
    }

    public void setdisSayisi(int disSayisi){
        this.disSayisi= disSayisi;
    }
    public int getdisSayisi(){
        return disSayisi;
    }


    public void hareketHizi(int hiz){
        System.out.printf("Köpeğin hareket hızı: %d m/s" , hiz);
    }


    public void kos(int hiz){
        System.out.println("Köpek koşuyor.");
        hareketHizi(hiz);
    }
}
