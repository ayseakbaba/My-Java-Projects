import java.util.Scanner;

public class Oop_Idman_Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("İdman Programına Hoşgeldiniz...");
        
        String idmanlar = "İdmandaki Hareketlerimiz :\n"
                        + "Burpee\n"
                        + "Push up(Şınav)\n"
                        + "Sit up (Mekik)\n"
                        + "Squat";
        System.out.println("************************************");
        System.out.println(idmanlar);
        System.out.println("************************************");

        System.out.println("Bir İdman Oluşturun:");
        System.out.print("Toplam Burpee Sayısı: ");
        int burpee = in.nextInt();
        System.out.print("Toplam Push Up Sayısı: ");
        int pushup = in.nextInt();
        System.out.print("Toplam Sit Up Sayısı: ");
        int situp = in.nextInt();
        System.out.print("Toplam Squat Sayısı: ");
        int squat = in.nextInt();
        in.nextLine();
        System.out.println("************************************");

        Oop_Idman idman = new Oop_Idman(burpee, pushup, situp, squat);
        System.out.println("İdmanınız Başlıyor...");

        while(idman.idmanbittiMi() == false){
            System.out.println("Şimdi Yapmak İstediğin Hareket(Burpee , Push up , Sit up , Squat) : ");
            String tur = in.nextLine();
            System.out.printf("Kaç Tane %s Yapacaksın:" , tur);
            int sayi = in.nextInt();
            in.nextLine();

            idman.hareketYap(tur, sayi);
        }

        System.out.println("*********************************");
        System.out.println("İdmanını Bitirdin. Tebrikler");
        System.out.println("Yine Görüşmek Üzere....");
        System.out.println("*********************************");
}
}
