public class Oop_Idman {
    private int burpee;
    private int pushup;
    private int situp;
    private int squat;

    public Oop_Idman(int burpee , int pushup , int situp , int squat){
        this.burpee= burpee;
        this.pushup= pushup;
        this.situp= situp;
        this.squat= squat;
    }

    public void setBurpee(int burpee){
        this.burpee= burpee;
    }
    public int getBurpee(){
        return burpee;
    }


    public void setPushup(int pushup){
        this.pushup= pushup;
    }
    public int getPushup(){
        return pushup;
    }


    public void setSitup(int situp){
        this.situp= situp;
    }
    public int getSitup(){
        return situp;
    }


    public void setSquat(int squat){
        this.squat= squat;
    }
    public int getSquat(){
        return squat;
    }


    public void hareketYap(String hareketTuru , int sayi){
        if(hareketTuru.equals("Burpee")){
            burpeeYap(sayi);
        }
        else if(hareketTuru.equals("Push up")){
            pushupYap(sayi);
        }
        else if(hareketTuru.equals("Sit up")){
            situpYap(sayi);
        }
        else if(hareketTuru.equals("Squat")){
            squatYap(sayi);
        }
        else{
            System.out.println("Geçersiz Hareket...");
        }
    }


    public void burpeeYap(int sayi){
        if (burpee - sayi == 0 ){
            burpee = 0;
            System.out.println("Kalan Burpee = 0");
            System.out.println("Yapacak Burpee Hareketi Kalmadı.");
            System.out.println("************************************");
        }
        else if (burpee - sayi < 0){
            System.out.println("Kendini Aştın. Tebrikler");
            burpee = 0;
            System.out.println("Kalan Burpee Sayısı = " + burpee);
            System.out.println("************************************");
        }else{
            burpee -= sayi;
            System.out.printf("Az Kaldı Dayan. Son %d Burpee%n" , burpee);
            System.out.println("************************************");
        }
    }


    public void pushupYap(int sayi){
        if (pushup - sayi== 0 ){
            pushup=0;
            System.out.println("Kalan Push Up = 0");
            System.out.println("Yapacak Push up Hareketi Kalmadı.");
            System.out.println("************************************");
        }
        else if (pushup - sayi < 0){
            System.out.println("Kendini Aştın. Tebrikler");
            pushup = 0;
            System.out.println("Kalan Push up Sayısı = " + pushup);
            System.out.println("************************************");
        }else{
            pushup -= sayi;
            System.out.printf("Az Kaldı Dayan. Son %d Pushup%n" , pushup);
            System.out.println("************************************");
        }
    }


    public void situpYap(int sayi){
        if (situp - sayi== 0 ){
            situp = 0;
            System.out.println("Kalan Sit Up = 0");
            System.out.println("Yapacak Sit up Hareketi Kalmadı.");
            System.out.println("************************************");
        }
        else if (situp - sayi < 0){
            System.out.println("Kendini Aştın. Tebrikler");
            situp = 0;
            System.out.println("Kalan Sit up Sayısı = " + situp);
            System.out.println("************************************");
        }else{
            situp -= sayi;
            System.out.printf("Az Kaldı Dayan. Son %d Sit up%n" , situp);
            System.out.println("************************************");
        }
    }


    public void squatYap(int sayi){
        if (squat - sayi== 0 ){
            squat = 0;
            System.out.println("Kalan Squat = 0");
            System.out.println("Yapacak Squat Hareketi Kalmadı.");
            System.out.println("************************************");
        }
        else if (squat - sayi < 0){
            System.out.println("Kendini Aştın. Tebrikler");
            squat = 0;
            System.out.println("Kalan Squat Sayısı = " + squat);
            System.out.println("************************************");
        }else{
            squat -= sayi;
            System.out.printf("Az Kaldı Dayan. Son %d Squat%n" , squat);
            System.out.println("************************************");
        }
    }

    public boolean idmanbittiMi(){
        return (burpee == 0) && (pushup == 0) && (situp == 0) && (squat == 0);
    }
}
