public class Inheritance_Yoneticiler extends Inheritance_Calisanlar{
    private int sorumluKisiSayisi;

    public Inheritance_Yoneticiler(String ad , String soyad , int id , int sorumluKisiSayisi){
        super(ad, soyad, id);
        this.sorumluKisiSayisi = sorumluKisiSayisi;
    }

    public void setSorumluKisiSayisi(int sorumluKisiSayisi){
        this.sorumluKisiSayisi = sorumluKisiSayisi;
    }
    public int getSorumluKisiSayisi(){
        return sorumluKisiSayisi;
    }


    public void zamYap(int zam){
        System.out.printf("Çalışanlara %d TL zam yapıldı.%n" , zam);
    }


    public void bilgilerigoster(){
        super.bilgilerigoster();
        System.out.println("Sorumlu Olduğu Kişi Sayısı: " + sorumluKisiSayisi);
    }
}
