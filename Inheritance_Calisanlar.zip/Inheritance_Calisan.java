public class Inheritance_Calisan {//SuperClass or BaseClass
    private String isim;
    private int maas;
    private String departman;

    public Inheritance_Calisan(String isim , int maas , String departman){
        this.isim= isim;
        this.maas = maas;
        this.departman = departman;
    }


    public void calıs(){
        System.out.println("Çalışan çalısıyor");
    }

    public void bilgilerigöster(){
        System.out.println("İsim: " + isim);
        System.out.println("Departman: " + departman);
        System.out.println("Maaş: " + maas);
    }


    public void setIsim (String isim){
        this.isim= isim;
    }
    public String getIsim(){
        return isim;
    }


    public void setMaas(int maas){
        this.maas = maas;
    }
    public int getMaas(){
        return maas;
    }


    public void setDepartman(String departman){
        this.departman= departman;
    }
    public String getDepartman(){
        return departman;
    }

    public void departman_degistirme(String yeni_departman){
        System.out.println("Departman değiştiriliyor.");
        this.departman= yeni_departman;
        System.out.println("Yeni departmanı: " + yeni_departman);
    }
    
}
