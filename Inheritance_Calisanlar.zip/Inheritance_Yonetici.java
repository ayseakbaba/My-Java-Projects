public class Inheritance_Yonetici extends Inheritance_Calisan {// SubClass
    //extends: (Class'ın ismi) clasındaki tüm bilgileri kullanmak istiyorum demek.
    //Yani kalıtım yapmak istediğinde kullanılan bir anahtar kelime

    private int sorumluKisiSayisi;//Ekstra özellik eklenebilir.

    public Inheritance_Yonetici(String isim, int maas, String departman , int sorumluKisiSayisi){
        super(isim, maas, departman);
        this.sorumluKisiSayisi = sorumluKisiSayisi;
        //super() fonksiyonu baseclass'taki bir constructor'ı kullanmak istediğimizde kullanırız.
        //Eğer bu constructor bu classta olsaydı this() fonksiyonunu kullanacaktık.
    }

    public void zammiktari(int zam){//Ekstra method yazılabilir.
        System.out.printf("Çalışanlara %d TL zam yapıldı" , zam);
    }

    public void bilgilerigöster(){//Inheritance'da overriding yaptım

        /*System.out.println("İsim: " + getIsim());
        System.out.println("Departman: " + getDepartman());
        System.out.println("Maaş: " + getMaas());*/

        super.bilgilerigöster();//yukardaki 3 satırlık kod ile bu aynı anlama geliyor.
        System.out.println("Sorumlu Olduğu Kişi Sayısı: " + sorumluKisiSayisi);
    }
}
