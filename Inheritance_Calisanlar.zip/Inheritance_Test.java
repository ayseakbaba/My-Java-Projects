public class Inheritance_Test {
    public static void main(String[] args) {
    Inheritance_Yonetici yonetici = new Inheritance_Yonetici("Ayşe AKBABA", 2500, "IT" , 200);
    yonetici.bilgilerigöster();

    yonetici.zammiktari(450);

    }
}
