public class Polymorphism_Beyblade {
    private String beybladePlayer;
    private int rotationSpeed;
    private int attackPower;

    public Polymorphism_Beyblade(String beybladePlayer , int rotationSpeed , int attackPower){
        this.beybladePlayer = beybladePlayer;
        this.rotationSpeed = rotationSpeed;
        this.attackPower = attackPower;
    }

    public void setBeybladePlayer(String beybladePlayer){
        this.beybladePlayer = beybladePlayer;
    }
    public String getBeybladePlayer(){
        return beybladePlayer;
    }


    public void setRotationSpeed(int rotationSpeed){
        this.rotationSpeed = rotationSpeed;
    }
    public int getRotationSpeed(){
        return rotationSpeed;
    }


    public void setAttackPower(int attackPower){
        this.attackPower = attackPower;
    }
    public int getAttackPower(){
        return attackPower;
    }


    public void attack(){
        System.out.printf("%s %d gücü ve %d hızıyla saldırıyor. %n" , beybladePlayer, attackPower , rotationSpeed);
    }


    public void show_the_holy_monster(){
        System.out.println("Bu beyblade'in kutsal canavarı bulunmamaktadır.");
    }


    public void show_the_informations(){
        System.out.println("Beyblade Oyuncusu: " +beybladePlayer);
        System.out.println("Saldırı Gücü: " + attackPower);
        System.out.println("Dönüş Hızı: " + rotationSpeed);
    }
}
