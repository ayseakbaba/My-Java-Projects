public class Polymorphism_Beyblade_Factory {
    public Polymorphism_Beyblade produce_beyblade(String type_of_beyblade){
        if(type_of_beyblade.equals("Dragon")){
            return new Polymorphism_Beyblade_Dragon("Takao", 800, 300, "Mavi Ejderha", "Kutsal Canavarla Konuşmak");
        }else if(type_of_beyblade.equals("Dranza")){
            return new Polymorphism_Beyblade_Dranza("Kai", 600, 400, "Kırmızı Anka Kuşu");
        }else if(type_of_beyblade.equals("Draciel")){
            return new Polymorphism_Beyblade_Draciel("Max", 400, 1000, "Kara Kaplumbağa");
        }else if(type_of_beyblade.equals("Drayga")){
            return new Polymorphism_Beyblade_Drayga("Rei", 800, 250, "Beyaz Kaplan");
        }else{
            return null;
        }
    }
}
