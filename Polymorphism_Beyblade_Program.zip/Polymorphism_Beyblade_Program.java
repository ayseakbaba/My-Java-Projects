import java.util.Scanner;
public class Polymorphism_Beyblade_Program {
    public static void main(String[] args) {
        System.out.println("...Beyblade Programina Hosgeldiniz...");
        System.out.println("Cikis icin q'ya basiniz.");
        Scanner in = new Scanner(System.in);
        while(true){
            String islem = in.nextLine();
            System.out.println("Hangi beyblade'i uretmek istiyorsunuz?: ");
            if(islem.equals("q")){
                System.out.println("Programdan Cıkılıyor...");
                break;
            }else{
                Polymorphism_Beyblade_Factory factory = new Polymorphism_Beyblade_Factory();
                Polymorphism_Beyblade beyblade = factory.produce_beyblade(islem);
                if(beyblade == null){
                    System.out.println("Lutfen gecerli bir beyblade ismi giriniz!");
                }else{
                    beyblade.show_the_informations();
                    beyblade.show_the_holy_monster();
                    beyblade.attack();

                }

            }
        }
    }
}
