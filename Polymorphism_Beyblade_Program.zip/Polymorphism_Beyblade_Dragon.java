public class Polymorphism_Beyblade_Dragon  extends Polymorphism_Beyblade{
    private String holyMonster;
    private String secretSkill;

    public Polymorphism_Beyblade_Dragon(String beybladePlayer , int attackPower , int rotationSpeed , String holyMonster , String secretSkill){
        super(beybladePlayer , attackPower , rotationSpeed);
        this.holyMonster = holyMonster;
        this.secretSkill = secretSkill;
    }

    public void show_the_informations(){
        super.show_the_informations();
        System.out.println("Kutsal Canavarı: " + holyMonster);
        System.out.println("Gizli Yeteneği: " + secretSkill);
    }

    public void show_the_holy_monster(){
        System.out.printf("&s , %s kutsal canavarını ortaya çıkardı. %n" , getBeybladePlayer() , holyMonster);
        System.out.printf("%s Oyuncusunun Gizli Saldırısı: Hayalet Kasırgası %n" , getBeybladePlayer());
    }
}
