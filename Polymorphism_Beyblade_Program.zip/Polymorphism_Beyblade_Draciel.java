public class Polymorphism_Beyblade_Draciel extends Polymorphism_Beyblade {
    private String holyMonster;

    public Polymorphism_Beyblade_Draciel(String beybladePlayer , int attackPower , int rotationSpeed , String holyMonster){
        super(beybladePlayer , attackPower , rotationSpeed);
        this.holyMonster = holyMonster;
    }

    public void show_the_informations(){
        super.show_the_informations();
        System.out.println("Kutsal Canavarı: " + holyMonster);
    }

    public void show_the_holy_monster(){
        System.out.printf("&s , %s kutsal canavarını ortaya çıkardı. %n" , getBeybladePlayer() , holyMonster);
        System.out.printf("%s Oyuncusunun Gizli Savunması: Kale Savunması %n" , getBeybladePlayer());
    }
}
