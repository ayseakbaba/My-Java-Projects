import java.util.Scanner;

public class Inheritance_Calisanlar_Test {
    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        System.out.println("Çalışanlar Programına Hoşgeldiniz.");
        String islemler = "İşlemler:\n"
                         +"1. Yazılımcı İşlemleri\n"
                         +"2.Yönetici İşlemleri\n"
                         +"Çıkış için q'ya basın";
        System.out.println("***************************************");
        System.out.println(islemler);
        System.out.println("***************************************");

        while(true){
            System.out.print("işlemi Seçiniz: ");
            String islem = in.nextLine();

            if(islem.equals("1")){
                Inheritance_Yazilimci yazilimci = new Inheritance_Yazilimci("Ayşe", "AKBABA", 236, "Java , Python");
                String yazilimciIslemleri = "Yazılımcı İşlemleri\n"
                                           +"1. Format Atma\n"
                                           +"2. Bilgileri Gösterme\n"
                                           +"Çıkış için q'ya basın.";
                System.out.println("*********************************");
                System.out.println(yazilimciIslemleri);
                System.out.println("*********************************");

                while(true){
                    System.out.print("Yazılımcı İşlemi Seçiniz: ");
                    String yazilimciIslem = in.nextLine();

                    if(yazilimciIslem.equals("1")){
                        System.out.print("İşletim Sistemi: ");
                        String isletimSistemi = in.nextLine();
                        yazilimci.formatAt(isletimSistemi);
                    }
                    else if(yazilimciIslem.equals("2")){
                        yazilimci.bilgilerigoster();
                    }
                    else if (yazilimciIslem.equals("q")){
                        System.out.println("Yazılımcı işlemlerinden Çıkılıyor...");
                        break;
                    }
                    else{
                        System.out.println("Geçersiz İşlem...");
                    }
                }
            }
            else if(islem.equals("2")){
                Inheritance_Yoneticiler yonetici = new Inheritance_Yoneticiler("Aras", "Çınar", 123, 25);
                String yoneticiIslemleri = "Yönetici İşlemleri\n"
                                          +"1. Zam Yapma\n"
                                          +"2. Bilgileri Gösterme\n"
                                          +"Çıkış için q'ya basın.";
                System.out.println("*********************************");
                System.out.println(yoneticiIslemleri);
                System.out.println("*********************************");

                while(true){
                    System.out.print("Yönetici İşlemi Seçiniz: ");
                    String yoneticiIslem = in.nextLine();

                    if(yoneticiIslem.equals("1")){
                        System.out.print("Zam Miktarı: ");
                        int zam = in.nextInt();
                        in.nextLine();
                        yonetici.zamYap(zam);
                    }
                    else if(yoneticiIslem.equals("2")){
                        yonetici.bilgilerigoster();
                    }
                    else if(yoneticiIslem.equals("q")){
                        System.out.println("Yönetici İşlemlerinden Çıkılıyor...");
                        break;
                    }
                    else{
                        System.out.println("Geçersiz İşlem...");
                    }
                }
            }
            else if(islem.equals("q")){
                System.out.println("Programdan Çıkılıyor. Yine Bekleriz...");
                break;
            }
            else{
                System.err.println("Geçersiz İşlem...");
            }
        }
    }
}
