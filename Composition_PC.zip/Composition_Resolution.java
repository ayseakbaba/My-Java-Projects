public class Composition_Resolution {
    private int en;
    private int boy;

    public Composition_Resolution(int en , int boy){
        this.en = en;
        this.boy = boy;
    }

    public void setEn(int en){
        this.en = en;
    }
    public int getEn(){
        return en;
    }


    
    public void setBoy(int boy){
        this.boy = boy;
    }
    public int getBoy(){
        return boy;
    }
}
