public class Composition_Test {
    public static void main(String[] args) {
        Composition_Resolution resolution = new Composition_Resolution(1920, 1080);
        Composition_Monitor monitor = new Composition_Monitor("VS197DE", "ASUS", "18.8", resolution);
        Composition_Kasa kasa = new Composition_Kasa("Shadow Blade" , "Shadow" , "Temperli Cam");
        Composition_Anakart anakart = new Composition_Anakart("B250-PRO", "ASUS", 10, "Windows 10");
        Composition_Bilgisayar pc = new Composition_Bilgisayar(monitor, kasa, anakart);

        pc.getKasa().bilgisayari_ac();
        pc.getMonitor().monitoru_kapat();
        pc.getAnakart().isletimSistemi_yükle("Ubuntu 16.04");
    }
}
