public class Composition_Bilgisayar {
    private Composition_Monitor monitor;
    private Composition_Kasa kasa;
    private Composition_Anakart anakart;

    public Composition_Bilgisayar(Composition_Monitor monitor , Composition_Kasa kasa , Composition_Anakart anakart){
        this.monitor = monitor;
        this.kasa = kasa;
        this.anakart = anakart;
    }


    public void setMonitor(Composition_Monitor monitor){
        this.monitor = monitor;
    }
    public Composition_Monitor getMonitor(){
        return monitor;
    }


    public void setKasa(Composition_Kasa kasa){
        this.kasa = kasa;
    } 
    public Composition_Kasa getKasa(){
        return kasa;
    }


    public void setAnakart(Composition_Anakart anakart){
        this.anakart = anakart;
    }
    public Composition_Anakart getAnakart(){
        return anakart;
    }
}
