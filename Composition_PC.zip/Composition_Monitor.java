public class Composition_Monitor {
    private String model;
    private String uretici;
    private String boyut;
    private Composition_Resolution resolution;

    public Composition_Monitor(String model , String uretici , String boyut, Composition_Resolution resolution){
        this.model = model;
        this.uretici = uretici;
        this.boyut = boyut;
        this.resolution = resolution;
    }

    public void monitoru_kapat(){
        System.out.println("Monitor kapatılıyor...");
    }

    public void setModel(String model){
        this.model = model;
    }
    public String getModel(){
        return model;
    }


    public void setUretici(String uretici){
        this.uretici= uretici;
    }
    public String getUretici(){
        return uretici;
    }


    public void setBoyut(String boyut){
        this.boyut = boyut;
    }
    public String getBoyut(){
        return boyut;
    }


    public void setResolution(Composition_Resolution resolution){
        this.resolution = resolution;
    }
    public Composition_Resolution getResolution(){
        return resolution;
    }
}
