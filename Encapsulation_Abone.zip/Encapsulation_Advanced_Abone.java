public class Encapsulation_Advanced_Abone {
    private String name;
    private int remainder = 120;
    private String city;

    public Encapsulation_Advanced_Abone(String name , int remainder , String city){
        this.name = name;

        if(remainder <= 0 && remainder >=120){
        this.remainder = remainder;
        }
        this.city = city;
    }

    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return name;
    }


    public void setRemainder(int remainder){
        this.remainder = remainder;
    }
    public int getRemainder(){
        return remainder;
    }


    public void setCity(String city){
        this.city = city;
    }
    public String getCity(){
        return city;
    }


    public void use_naturalgas(int amount){
        if(remainder < amount){
            System.out.println("Yetersiz Bakiye");
        }else{
            this.remainder -= amount;
            if(this.remainder<=0){
                System.out.println("Bakiyeniz Bitmistir. Lutfen en yakin abone merkezinden kredi yukleyiniz."
                + "Kredi Limiti:120 TL");
            }else{
                System.out.printf("Kalan Bakiye: %d" , remainder);
            }
        }

    }

    public void  interrogate_to_remainder(){
        System.out.printf("Bakiyeniz: %d%n" , remainder);
    }
}
