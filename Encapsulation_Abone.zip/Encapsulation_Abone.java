//This programme is about a natural gas subscriber
public class Encapsulation_Abone {
    public String name;
    public int remainder;
    public String city;

    public void use_naturalgas(int amount){
        if(remainder < amount){
            System.out.println("Yetersiz Bakiye");
        }else{
            this.remainder -= amount;
            if(this.remainder<=0){
                System.out.println("Bakiyeniz Bitmistir. Lutfen en yakin abone merkezinden kredi yukleyiniz."
                + "Kredi Limiti:120 TL");
            }else{
                System.out.printf("Kalan Bakiye: %d" , remainder);
            }
        }

    }

    public void  interrogate_to_remainder(){
        System.out.printf("Bakiyeniz: %d%n" , remainder);
    }
}
