public class Encapsulation_Abone_Test {
    public static void main(String[] args) {
       /* Encapsulation_Abone abone = new Encapsulation_Abone();

        abone.name = "Ayşe Akbaba";
        abone.remainder = 200;
        abone.city= "Sivas";
        abone.use_naturalgas(200);
        */

        Encapsulation_Advanced_Abone abone = new Encapsulation_Advanced_Abone("Ayşe AKBABA", 200, "Sivas/Merkez");
        abone.interrogate_to_remainder();
    }
}
